import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: const TodoHomePage(),
    );
  }
}

class TodoHomePage extends StatefulWidget {
  const TodoHomePage({super.key});

  @override
  State<TodoHomePage> createState() => _TodoHomePageState();
}

class _TodoHomePageState extends State<TodoHomePage> {
  List<Map<String, dynamic>> _todoList = [];
  final TextEditingController _textController = TextEditingController();
   final String apiUrl = 'http://localhost:3000/todos';
// Use 127.0.0.1 or localhost if on desktop
 

  @override
  void initState() {
    super.initState();
    _fetchTodos();
  }

  String getCurrentDate() {
    final now = DateTime.now();
    return '${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(2, '0')}/${now.year}';
  }

  Future<void> _fetchTodos() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        setState(() {
          _todoList = List<Map<String, dynamic>>.from(data);
        });
      } else {
        print('Error fetching todos: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching todos: $e');
    }
  }

  Future<void> _addTodoItem(String task) async {
    if (task.trim().isEmpty) return;
    final newTodo = {
      'task': task,
      'completed': false,
      'date': getCurrentDate(),
    };
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(newTodo),
      );
      if (response.statusCode == 200) {
        await _fetchTodos();
        _textController.clear();
      }
    } catch (e) {
      print('Error adding todo: $e');
    }
  }

  Future<void> _toggleTodoStatus(int index) async {
    final todo = _todoList[index];
    final updatedTodo = {
      'task': todo['task'],
      'completed': !todo['completed'],
      'date': todo['date'],
    };
    try {
      final response = await http.put(
        Uri.parse('$apiUrl/${todo['id']}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(updatedTodo),
      );
      if (response.statusCode == 200) {
        await _fetchTodos();
      }
    } catch (e) {
      print('Error updating todo: $e');
    }
  }

  Future<void> _deleteTodoItem(int index) async {
    final id = _todoList[index]['id'];
    try {
      final response = await http.delete(Uri.parse('$apiUrl/$id'));
      if (response.statusCode == 200) {
        await _fetchTodos();
      }
    } catch (e) {
      print('Error deleting todo: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final int completedCount =
        _todoList.where((item) => item['completed'] == true).length;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFB388FF), Color(0xFF7C4DFF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      'To-Do App',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '$completedCount of ${_todoList.length} tasks completed',
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: TextField(
                              controller: _textController,
                              decoration: const InputDecoration(
                                hintText: 'What needs to be done?',
                                border: InputBorder.none,
                                contentPadding:
                                    EdgeInsets.symmetric(horizontal: 12),
                              ),
                              onSubmitted: _addTodoItem,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: () => _addTodoItem(_textController.text),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepPurple,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.all(14),
                          ),
                          child: const Icon(Icons.add),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _todoList.isEmpty
                  ? const Center(
                      child: Text(
                        'No tasks yet. Add one!',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: _todoList.length,
                      itemBuilder: (context, index) {
                        final task = _todoList[index];
                        return Container(
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: ListTile(
                            leading: Checkbox(
                              value: task['completed'],
                              onChanged: (_) => _toggleTodoStatus(index),
                            ),
                            title: Text(
                              task['task'],
                              style: TextStyle(
                                decoration: task['completed']
                                    ? TextDecoration.lineThrough
                                    : TextDecoration.none,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            subtitle: Text(task['date']),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete),
                              onPressed: () => _deleteTodoItem(index),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}


